##############################################################
# Name : Chen Yun
# Section : G3
##############################################################
import cvxpy as cp
import sympy as sp

def ilp(expr):
    """Check satisfiability of a propositional sentence via a ILP.
    Args:
        expr: a logic expression
    Returns:
        (Boolean) True if satisfiable; Otherwise, false.
    """
    # transform expr into cvxpy variables
    cvx_var = var_from_expr(expr)
    
    # Write your codes here
    constraints = []
    # Create constraints
    for arg in expr.args:
        clause = arg.args if len(arg.args) > 1 else [arg]
        lhs = create_LHS(clause, cvx_var)
        
        # Since is or (||) condition, as long as one or more var is true, whole expression is true
        constraints.append(lhs >= 1)
    
    symbols = [sp.symbols(v) for v in cvx_var.keys()]
    objective = create_LHS(symbols, cvx_var)
    
    problem = cp.Problem(cp.Maximize(objective), constraints)
    problem.solve(solver="GLPK_MI")
    if problem.status == 'optimal':
        return True
    else:
        return False

# ---- Helper functions ----
def var_from_expr(expr):
    """Transform expr into cvxpy variables 
    """
    var_dict = {}
    for atom in expr.atoms():
        var_dict[str(atom)] = cp.Variable(boolean=True)
    
    return var_dict

def create_LHS(symbols: list, var: dict):
    """Create left-hand side (LHS) of a constraint in ILP.

    This function returns the summation of a list of symbols which
    is used to construct constraints of this ILP.
    E.g. symbols = [x0, x1, ~x2] will be converted into `x0 + x1 +
    1 - x2, called expression. You can then use this expression to 
    construct:
        Equality constraint:   `x0 + x1 + 1 - x2 == 1`
        Inequality constraint: `x0 + x1 + 1 - x2 <= 1`

    Note:
        This function is not necessary. Please feel free to develop
        your own help function. 
    
    Args:
        symbols: a list contains sympy.core.symbol.Symbol (or strings)
        var: a dictionary contains cvxpy variables. 
    """
    con_LHS = 0
    for s in symbols:
        s = str(s)
        if s[0] == '~': # if its logic Not, plus `1-variable`
            con_LHS += 1-var[s[1:]]
        else:           # else, plus `variable`
            con_LHS += var[s]
    return con_LHS
